create definer = root@localhost view event_order as
select `new_irm`.`fdm_ewm_jd`.`id`                                 AS `id`,
       `new_irm`.`fdm_ewm_jd`.`event_order`                        AS `event_order`,
       `new_irm`.`fdm_ewm_jd`.`event_username`                     AS `event_username`,
       `new_irm`.`fdm_ewm_jd`.`event_erp`                          AS `event_erp`,
       `new_irm`.`fdm_ewm_jd`.`event_email`                        AS `event_email`,
       `new_irm`.`fdm_ewm_jd`.`event_department`                   AS `event_department`,
       `new_irm`.`fdm_ewm_jd`.`event_seat`                         AS `event_seat`,
       `new_irm`.`fdm_ewm_jd`.`event_ip`                           AS `event_ip`,
       `new_irm`.`fdm_ewm_jd`.`event_register_name`                AS `event_register_name`,
       `new_irm`.`fdm_ewm_jd`.`event_register_erp`                 AS `event_register_erp`,
       `new_irm`.`fdm_ewm_jd`.`event_first_area`                   AS `event_first_area`,
       `new_irm`.`fdm_ewm_jd`.`event_second_area`                  AS `event_second_area`,
       `new_irm`.`fdm_ewm_jd`.`event_third_area`                   AS `event_third_area`,
       `new_irm`.`fdm_ewm_jd`.`event_level`                        AS `event_level`,
       `new_irm`.`fdm_ewm_jd`.`event_from_source`                  AS `event_from_source`,
       `new_irm`.`fdm_ewm_jd`.`event_response_status`              AS `event_response_status`,
       `new_irm`.`fdm_ewm_jd`.`event_handle_reason`                AS `event_handle_reason`,
       `new_irm`.`fdm_ewm_jd`.`event_rollback_reason`              AS `event_rollback_reason`,
       `new_irm`.`fdm_ewm_jd`.`event_cancel_reason`                AS `event_cancel_reason`,
       `new_irm`.`fdm_ewm_jd`.`event_reopen_reason`                AS `event_reopen_reason`,
       `new_irm`.`fdm_ewm_jd`.`event_current_do_person`            AS `event_current_do_person`,
       `new_irm`.`fdm_ewm_jd`.`event_current_do_person_area`       AS `event_current_do_person_area`,
       `new_irm`.`fdm_ewm_jd`.`event_area_belong`                  AS `event_area_belong`,
       `new_irm`.`fdm_ewm_jd`.`event_helper_erp`                   AS `event_helper_erp`,
       `new_irm`.`fdm_ewm_jd`.`event_desc`                         AS `event_desc`,
       `new_irm`.`fdm_ewm_jd`.`event_catalog1`                     AS `event_catalog1`,
       `new_irm`.`fdm_ewm_jd`.`event_catalog2`                     AS `event_catalog2`,
       `new_irm`.`fdm_ewm_jd`.`event_catalog3`                     AS `event_catalog3`,
       `new_irm`.`fdm_ewm_jd`.`event_machine_count`                AS `event_machine_count`,
       `new_irm`.`fdm_ewm_jd`.`event_deal_solution`                AS `event_deal_solution`,
       `new_irm`.`fdm_ewm_jd`.`event_deal_way`                     AS `event_deal_way`,
       `new_irm`.`fdm_ewm_jd`.`event_source`                       AS `event_source`,
       `new_irm`.`fdm_ewm_jd`.`event_create_time`                  AS `event_create_time`,
       `new_irm`.`fdm_ewm_jd`.`event_first_response_time`          AS `event_first_response_time`,
       `new_irm`.`fdm_ewm_jd`.`event_last_flow_time`               AS `event_last_flow_time`,
       `new_irm`.`fdm_ewm_jd`.`event_deal_times`                   AS `event_deal_times`,
       `new_irm`.`fdm_ewm_jd`.`event_done_time`                    AS `event_done_time`,
       `new_irm`.`fdm_ewm_jd`.`event_total_deal_time`              AS `event_total_deal_time`,
       `new_irm`.`fdm_ewm_jd`.`event_finally_deal_person_use_time` AS `event_finally_deal_person_use_time`,
       `new_irm`.`fdm_ewm_jd`.`event_response_timeout`             AS `event_response_timeout`,
       `new_irm`.`fdm_ewm_jd`.`event_is_work_day`                  AS `event_is_work_day`,
       `new_irm`.`fdm_ewm_jd`.`event_is_from_service_platform`     AS `event_is_from_service_platform`,
       `new_irm`.`fdm_ewm_jd`.`event_is_first_deal`                AS `event_is_first_deal`,
       `new_irm`.`fdm_ewm_jd`.`event_flow_times`                   AS `event_flow_times`,
       `new_irm`.`fdm_ewm_jd`.`event_first_response_erp`           AS `event_first_response_erp`,
       `new_irm`.`fdm_ewm_jd`.`event_handler_time`                 AS `event_handler_time`,
       `new_irm`.`fdm_ewm_jd`.`event_handler_person`               AS `event_handler_person`,
       `new_irm`.`fdm_ewm_jd`.`event_is_handler`                   AS `event_is_handler`
from `new_irm`.`fdm_ewm_jd`
where ((`new_irm`.`fdm_ewm_jd`.`event_response_status` <> '已取消') and
       (`new_irm`.`fdm_ewm_jd`.`event_catalog1` <> '无效工单'));

-- comment on column event_order.event_order not supported: 事件单号	

-- comment on column event_order.event_username not supported: 事主姓名

-- comment on column event_order.event_erp not supported: 事主erp

-- comment on column event_order.event_email not supported: 事主邮箱

-- comment on column event_order.event_department not supported: 事主部门

-- comment on column event_order.event_seat not supported: 事主工位

-- comment on column event_order.event_ip not supported: 事主IP

-- comment on column event_order.event_register_name not supported: 登记人名字

-- comment on column event_order.event_register_erp not supported: 登记人ERP

-- comment on column event_order.event_first_area not supported: 一级区域名称

-- comment on column event_order.event_second_area not supported: 二级区域名称

-- comment on column event_order.event_third_area not supported: 三级区域名称

-- comment on column event_order.event_level not supported: 事件优先级

-- comment on column event_order.event_from_source not supported: 事件来源

-- comment on column event_order.event_response_status not supported: 事件单状态

-- comment on column event_order.event_handle_reason not supported: 挂起原因

-- comment on column event_order.event_rollback_reason not supported: 退回原因

-- comment on column event_order.event_cancel_reason not supported: 取消原因

-- comment on column event_order.event_reopen_reason not supported: 重开原因

-- comment on column event_order.event_current_do_person not supported: 当前处理人

-- comment on column event_order.event_current_do_person_area not supported: 当前处理人区域

-- comment on column event_order.event_area_belong not supported: 人事归属

-- comment on column event_order.event_helper_erp not supported: 协助人ERP

-- comment on column event_order.event_desc not supported: 事件描述

-- comment on column event_order.event_catalog1 not supported: 一级分类

-- comment on column event_order.event_catalog2 not supported: 二级分类

-- comment on column event_order.event_catalog3 not supported: 三级分类	

-- comment on column event_order.event_machine_count not supported: 设备数量

-- comment on column event_order.event_deal_solution not supported: 解决方案

-- comment on column event_order.event_deal_way not supported: 解决方式

-- comment on column event_order.event_source not supported: 报告来源

-- comment on column event_order.event_create_time not supported: 创建时间

-- comment on column event_order.event_first_response_time not supported: 首次响应时间

-- comment on column event_order.event_last_flow_time not supported: 最后一次流转时间

-- comment on column event_order.event_deal_times not supported: 响应时长(分钟)

-- comment on column event_order.event_done_time not supported: 解决时间

-- comment on column event_order.event_total_deal_time not supported: 总处理时长(分钟)

-- comment on column event_order.event_finally_deal_person_use_time not supported: 最终解决人处理时长(分钟)

-- comment on column event_order.event_response_timeout not supported: 响应超时

-- comment on column event_order.event_is_work_day not supported: 是否工作时间提交

-- comment on column event_order.event_is_from_service_platform not supported: 是否是服务台派单

-- comment on column event_order.event_is_first_deal not supported: 是否首次解决

-- comment on column event_order.event_flow_times not supported: 流转次数

-- comment on column event_order.event_first_response_erp not supported: 首次响应人ERP

-- comment on column event_order.event_handler_time not supported: 事件挂起时间

-- comment on column event_order.event_handler_person not supported: 事件挂起人

-- comment on column event_order.event_is_handler not supported: 判断事件是否挂起

