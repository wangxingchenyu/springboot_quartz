create definer = root@localhost view pc_less_ten as
select `p`.`id`                AS `id`,
       `p`.`system_producer`   AS `system_producer`,
       `p`.`system_type`       AS `system_type`,
       `p`.`system_processer`  AS `system_processer`,
       `p`.`hostname`          AS `hostname`,
       `p`.`system_version`    AS `system_version`,
       `p`.`physical_memory`   AS `physical_memory`,
       `p`.`mac_addr`          AS `mac_addr`,
       `p`.`c_area`            AS `c_area`,
       `p`.`run_time`          AS `run_time`,
       `p`.`register_user`     AS `register_user`,
       `p`.`dongdong_dir_size` AS `dongdong_dir_size`,
       `p`.`all_c_space`       AS `all_c_space`,
       `p`.`ost_file_size`     AS `ost_file_size`,
       `p`.`pre_login_time`    AS `pre_login_time`,
       `p`.`disks`             AS `disks`,
       `p`.`ip`                AS `ip`,
       `p`.`c_used_rate`       AS `c_used_rate`,
       `p`.`wulineicun`        AS `wulineicun`,
       `p`.`sn`                AS `sn`,
       `p`.`valiable_memory`   AS `valiable_memory`,
       `p`.`start_time`        AS `start_time`,
       `s`.`floor`             AS `floor`,
       `s`.`gongwei`           AS `gongwei`,
       `s`.`telephone_ip`      AS `telephone_ip`
from (`new_irm`.`pc_info` `p`
         left join `new_irm`.`sit_table` `s` on ((`s`.`computer_ip` = `p`.`ip`)))
where ((`p`.`run_time` > (now() - interval 10 minute)) and (`s`.`floor` <> '无线'));

-- comment on column pc_less_ten.dongdong_dir_size not supported: 0

-- comment on column pc_less_ten.floor not supported: 楼层

-- comment on column pc_less_ten.gongwei not supported: 工位

-- comment on column pc_less_ten.telephone_ip not supported: 电话ip

