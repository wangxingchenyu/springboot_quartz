create
    definer = root@localhost procedure p1(IN a int)
BEGIN

	DECLARE v1 int;

	set v1 = a;

	select * from pc_info where id> v1;
END;

